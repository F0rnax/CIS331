    <footer class="gradient">
      <div class="container-fluid text-center">
        <span
          >Made with <3 by
          <a href="https://mdbootstrap.com">MDBootstrap.com</a></span
        >
      </div>
    </footer>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>