<?php require('components/head.inc.php'); ?>
<?php include('components/navbar.inc.php'); ?>
<?php include('components/gallery.inc.php'); ?>
<?php require('components/footer.inc.php'); ?>
